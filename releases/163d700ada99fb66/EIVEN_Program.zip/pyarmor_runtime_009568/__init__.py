# Pyarmor 9.2.3 (basic), 009568, 2026-04-25T00:52:16.458127
from .pyarmor_runtime import __pyarmor__
