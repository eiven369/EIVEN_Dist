# Pyarmor 9.2.3 (basic), 009568, 2026-09-20T16:12:05.818897
from .pyarmor_runtime import __pyarmor__
