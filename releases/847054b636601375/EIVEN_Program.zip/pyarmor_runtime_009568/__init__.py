# Pyarmor 9.2.3 (basic), 009568, 2026-08-03T20:08:11.703777
from .pyarmor_runtime import __pyarmor__
