# Pyarmor 9.2.3 (basic), 009568, 2026-03-29T20:49:50.070851
from .pyarmor_runtime import __pyarmor__
