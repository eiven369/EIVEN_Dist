# Pyarmor 9.2.3 (basic), 009568, 2026-09-30T22:51:51.845524
from .pyarmor_runtime import __pyarmor__
