# Pyarmor 9.2.3 (basic), 009568, 2026-04-25T00:51:09.665824
from .pyarmor_runtime import __pyarmor__
