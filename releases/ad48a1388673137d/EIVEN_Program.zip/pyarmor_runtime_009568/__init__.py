# Pyarmor 9.2.3 (basic), 009568, 2026-03-02T14:05:50.921443
from .pyarmor_runtime import __pyarmor__
