# Pyarmor 9.2.3 (basic), 009568, 2026-10-04T12:23:05.629654
from .pyarmor_runtime import __pyarmor__
