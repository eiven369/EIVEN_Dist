# Pyarmor 9.2.3 (basic), 009568, 2026-09-30T22:53:53.851051
from .pyarmor_runtime import __pyarmor__
