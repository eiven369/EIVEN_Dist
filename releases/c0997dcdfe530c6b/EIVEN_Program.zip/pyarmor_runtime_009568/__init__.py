# Pyarmor 9.2.3 (basic), 009568, 2026-06-28T16:07:04.753206
from .pyarmor_runtime import __pyarmor__
