# Pyarmor 9.2.3 (basic), 009568, 2026-07-08T19:41:25.735056
from .pyarmor_runtime import __pyarmor__
