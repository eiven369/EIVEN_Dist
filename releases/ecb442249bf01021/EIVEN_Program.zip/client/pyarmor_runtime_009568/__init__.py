# Pyarmor 9.2.3 (basic), 009568, 2026-09-05T20:29:35.345809
from .pyarmor_runtime import __pyarmor__
