# Pyarmor 9.2.3 (basic), 009568, 2026-08-31T14:50:09.054556
from .pyarmor_runtime import __pyarmor__
