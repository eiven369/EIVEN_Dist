# Pyarmor 9.2.3 (basic), 009568, 2026-09-04T11:04:25.740569
from .pyarmor_runtime import __pyarmor__
