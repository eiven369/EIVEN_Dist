# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:14:41.819697
from .pyarmor_runtime import __pyarmor__
