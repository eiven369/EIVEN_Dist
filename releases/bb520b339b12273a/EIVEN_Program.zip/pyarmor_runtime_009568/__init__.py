# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:11:36.570074
from .pyarmor_runtime import __pyarmor__
