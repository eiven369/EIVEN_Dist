# Pyarmor 9.2.3 (basic), 009568, 2026-09-05T14:37:40.591820
from .pyarmor_runtime import __pyarmor__
