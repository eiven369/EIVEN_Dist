# Pyarmor 9.2.3 (basic), 009568, 2026-09-13T16:58:25.838833
from .pyarmor_runtime import __pyarmor__
