# Pyarmor 9.2.3 (basic), 009568, 2026-11-16T20:13:05.262657
from .pyarmor_runtime import __pyarmor__
