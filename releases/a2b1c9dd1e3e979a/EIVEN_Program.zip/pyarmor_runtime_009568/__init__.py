# Pyarmor 9.2.3 (basic), 009568, 2026-03-11T13:02:40.517412
from .pyarmor_runtime import __pyarmor__
