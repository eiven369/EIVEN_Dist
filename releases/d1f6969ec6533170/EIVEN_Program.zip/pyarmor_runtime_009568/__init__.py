# Pyarmor 9.2.3 (basic), 009568, 2026-08-02T11:17:57.486903
from .pyarmor_runtime import __pyarmor__
