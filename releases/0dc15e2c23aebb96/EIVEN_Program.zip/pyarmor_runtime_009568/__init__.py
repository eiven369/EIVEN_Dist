# Pyarmor 9.2.3 (basic), 009568, 2026-02-12T18:02:08.567288
from .pyarmor_runtime import __pyarmor__
