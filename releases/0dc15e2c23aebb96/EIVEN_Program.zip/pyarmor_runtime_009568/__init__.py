# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:12:45.665349
from .pyarmor_runtime import __pyarmor__
