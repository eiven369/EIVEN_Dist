# Pyarmor 9.2.3 (basic), 009568, 2026-03-01T23:26:09.317012
from .pyarmor_runtime import __pyarmor__
