# Pyarmor 9.2.3 (basic), 009568, 2026-02-28T22:48:31.504044
from .pyarmor_runtime import __pyarmor__
