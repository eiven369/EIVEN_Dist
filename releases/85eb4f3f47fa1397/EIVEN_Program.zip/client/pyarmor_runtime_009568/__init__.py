# Pyarmor 9.2.3 (basic), 009568, 2026-09-30T22:50:50.694715
from .pyarmor_runtime import __pyarmor__
