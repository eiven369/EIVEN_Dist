# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:12:49.177482
from .pyarmor_runtime import __pyarmor__
