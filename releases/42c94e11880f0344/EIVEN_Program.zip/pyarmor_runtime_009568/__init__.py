# Pyarmor 9.2.3 (basic), 009568, 2026-02-14T20:06:20.820192
from .pyarmor_runtime import __pyarmor__
