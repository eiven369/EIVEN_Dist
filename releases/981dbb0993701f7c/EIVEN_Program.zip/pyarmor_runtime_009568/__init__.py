# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:15:29.244942
from .pyarmor_runtime import __pyarmor__
