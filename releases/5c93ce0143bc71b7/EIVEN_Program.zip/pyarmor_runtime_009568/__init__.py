# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:10:05.620462
from .pyarmor_runtime import __pyarmor__
