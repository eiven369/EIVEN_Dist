# Pyarmor 9.2.3 (basic), 009568, 2026-07-15T15:40:49.066183
from .pyarmor_runtime import __pyarmor__
