# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:14:13.130503
from .pyarmor_runtime import __pyarmor__
