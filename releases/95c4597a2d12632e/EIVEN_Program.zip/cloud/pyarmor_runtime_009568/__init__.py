# Pyarmor 9.2.3 (basic), 009568, 2026-09-30T22:52:32.263983
from .pyarmor_runtime import __pyarmor__
