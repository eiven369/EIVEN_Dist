# Pyarmor 9.2.3 (basic), 009568, 2026-02-04T19:34:22.043622
from .pyarmor_runtime import __pyarmor__
