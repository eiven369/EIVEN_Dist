# Pyarmor 9.2.3 (basic), 009568, 2026-08-02T11:16:14.807280
from .pyarmor_runtime import __pyarmor__
