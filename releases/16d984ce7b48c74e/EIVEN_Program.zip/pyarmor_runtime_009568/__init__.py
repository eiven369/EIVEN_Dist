# Pyarmor 9.2.3 (basic), 009568, 2026-08-02T11:15:14.071586
from .pyarmor_runtime import __pyarmor__
