# Pyarmor 9.2.3 (basic), 009568, 2026-09-10T20:04:13.852349
from .pyarmor_runtime import __pyarmor__
