# Pyarmor 9.2.3 (basic), 009568, 2026-10-01T15:54:31.446215
from .pyarmor_runtime import __pyarmor__
