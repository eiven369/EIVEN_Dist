# Pyarmor 9.2.3 (basic), 009568, 2026-11-01T22:38:48.165009
from .pyarmor_runtime import __pyarmor__
