# Pyarmor 9.2.3 (basic), 009568, 2026-02-24T23:00:48.302065
from .pyarmor_runtime import __pyarmor__
