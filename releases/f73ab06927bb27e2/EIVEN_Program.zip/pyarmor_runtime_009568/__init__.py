# Pyarmor 9.2.3 (basic), 009568, 2026-04-30T19:59:42.820867
from .pyarmor_runtime import __pyarmor__
