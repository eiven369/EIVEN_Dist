# Pyarmor 9.2.3 (basic), 009568, 2026-06-25T16:40:49.367794
from .pyarmor_runtime import __pyarmor__
