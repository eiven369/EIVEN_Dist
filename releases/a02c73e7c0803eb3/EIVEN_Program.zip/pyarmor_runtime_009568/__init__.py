# Pyarmor 9.2.3 (basic), 009568, 2026-06-23T18:46:25.290342
from .pyarmor_runtime import __pyarmor__
