# Pyarmor 9.2.3 (basic), 009568, 2026-09-01T14:04:16.670294
from .pyarmor_runtime import __pyarmor__
