# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:16:44.274142
from .pyarmor_runtime import __pyarmor__
