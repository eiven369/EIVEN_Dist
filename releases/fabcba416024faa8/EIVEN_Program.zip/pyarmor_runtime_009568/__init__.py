# Pyarmor 9.2.3 (basic), 009568, 2026-09-14T16:23:42.959477
from .pyarmor_runtime import __pyarmor__
