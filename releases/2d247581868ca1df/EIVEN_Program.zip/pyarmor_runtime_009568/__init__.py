# Pyarmor 9.2.3 (basic), 009568, 2026-02-21T17:27:34.338770
from .pyarmor_runtime import __pyarmor__
