# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:14:34.546029
from .pyarmor_runtime import __pyarmor__
