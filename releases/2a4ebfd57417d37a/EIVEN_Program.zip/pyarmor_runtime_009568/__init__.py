# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:15:54.993887
from .pyarmor_runtime import __pyarmor__
