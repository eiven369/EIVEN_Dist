# Pyarmor 9.1.9 (basic), 009568, 2026-07-27T17:16:21.432171
from .pyarmor_runtime import __pyarmor__
