# Pyarmor 9.2.3 (basic), 009568, 2026-03-29T20:50:32.268435
from .pyarmor_runtime import __pyarmor__
