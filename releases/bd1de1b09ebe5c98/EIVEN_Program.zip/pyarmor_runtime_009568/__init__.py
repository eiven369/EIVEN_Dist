# Pyarmor 9.2.3 (basic), 009568, 2026-05-22T12:32:46.295337
from .pyarmor_runtime import __pyarmor__
