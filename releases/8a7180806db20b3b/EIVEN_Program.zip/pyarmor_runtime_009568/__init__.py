# Pyarmor 9.2.3 (basic), 009568, 2026-09-14T17:16:27.130333
from .pyarmor_runtime import __pyarmor__
