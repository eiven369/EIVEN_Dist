# Pyarmor 9.2.3 (basic), 009568, 2026-09-18T13:11:53.296814
from .pyarmor_runtime import __pyarmor__
