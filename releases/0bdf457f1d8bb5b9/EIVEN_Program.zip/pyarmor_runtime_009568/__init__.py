# Pyarmor 9.2.3 (basic), 009568, 2026-04-11T00:17:25.216990
from .pyarmor_runtime import __pyarmor__
