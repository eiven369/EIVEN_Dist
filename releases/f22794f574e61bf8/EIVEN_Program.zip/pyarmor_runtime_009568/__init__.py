# Pyarmor 9.2.3 (basic), 009568, 2026-03-25T15:19:30.698850
from .pyarmor_runtime import __pyarmor__
