# Pyarmor 9.2.3 (basic), 009568, 2026-02-21T17:22:42.621323
from .pyarmor_runtime import __pyarmor__
