# Pyarmor 9.2.3 (basic), 009568, 2026-03-05T13:28:37.840066
from .pyarmor_runtime import __pyarmor__
